"""Adaptative Perturbation Pattern Method package."""

from a2pm.a2pm import A2PMethod
