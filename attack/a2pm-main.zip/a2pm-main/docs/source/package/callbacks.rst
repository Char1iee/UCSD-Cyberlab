Callbacks
=========

BaseCallback
------------

.. autoclass:: a2pm.callbacks.BaseCallback

MetricCallback
--------------

.. autoclass:: a2pm.callbacks.MetricCallback

TimeCallback
------------

.. autoclass:: a2pm.callbacks.TimeCallback
