A2PMethod
=========

.. autoclass:: a2pm.A2PMethod
