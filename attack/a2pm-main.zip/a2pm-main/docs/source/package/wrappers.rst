Wrappers
========

BaseWrapper
-----------

.. autoclass:: a2pm.wrappers.BaseWrapper

KerasWrapper
------------

.. autoclass:: a2pm.wrappers.KerasWrapper

SklearnWrapper
--------------

.. autoclass:: a2pm.wrappers.SklearnWrapper

TorchWrapper
------------

.. autoclass:: a2pm.wrappers.TorchWrapper
