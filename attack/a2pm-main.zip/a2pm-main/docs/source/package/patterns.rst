Patterns
========

BasePattern
-----------

.. autoclass:: a2pm.patterns.BasePattern

CombinationPattern
------------------

.. autoclass:: a2pm.patterns.CombinationPattern

IntervalPattern
---------------

.. autoclass:: a2pm.patterns.IntervalPattern
